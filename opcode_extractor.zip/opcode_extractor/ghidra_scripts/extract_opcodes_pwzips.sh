#!/usr/bin/env bash
set -euo pipefail

DATASET_ROOT="${1:-}"
OUT_ROOT="${2:-./opcodes_out}"
ANALYZE_HEADLESS="${3:-/opt/ghidra/support/analyzeHeadless}"

ZIP_PASSWORD="infected"

if [[ -z "$DATASET_ROOT" ]]; then
  echo "Usage: $0 /path/to/dataset_root [/path/to/output_root]"
  exit 1
fi

if [[ ! -x "$ANALYZE_HEADLESS" ]]; then
  echo "analyzeHeadless not found at: $ANALYZE_HEADLESS"
  exit 1
fi

mkdir -p "$OUT_ROOT"

WORK_DIR="$(mktemp -d)"
trap "rm -rf $WORK_DIR" EXIT

process_sample() {
  local sample="$1"
  local output="$2"

  mkdir -p "$(dirname "$output")"

  PROJECT_DIR="$(mktemp -d -p "$WORK_DIR")"

  OPCODE_OUT="$output" \
  "$ANALYZE_HEADLESS" \
    "$PROJECT_DIR" proj \
    -import "$sample" \
    -analysisTimeoutPerFile 180 \
    -deleteProject \
    -scriptPath "$(pwd)/ghidra_scripts" \
    -postScript DumpOpcodes.java \
    >/dev/null 2>&1
}

echo "Scanning dataset: $DATASET_ROOT"
echo

mapfile -t ZIPS < <(find "$DATASET_ROOT" -type f -iname "*.zip")

for zipf in "${ZIPS[@]}"; do

  rel="${zipf#$DATASET_ROOT/}"
  group="${rel%%/*}"
  [[ "$group" != "$rel" ]] || group="UNKNOWN_GROUP"

  echo "Processing ZIP: $rel"

  UNZIP_DIR="$(mktemp -d -p "$WORK_DIR")"

  if ! unzip -P "$ZIP_PASSWORD" -qq "$zipf" -d "$UNZIP_DIR"; then
    echo "Failed unzip: $rel"
    continue
  fi

  mapfile -t FILES < <(find "$UNZIP_DIR" -type f)

  for f in "${FILES[@]}"; do
    base="$(basename "$f")"
    name="${base%.*}"
    output="$OUT_ROOT/$group/$name.opcode"

    echo "  -> $base"
    process_sample "$f" "$output"
  done

  echo
done

echo "Done."
