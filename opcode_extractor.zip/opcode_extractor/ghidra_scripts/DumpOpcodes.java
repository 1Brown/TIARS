import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.MemoryBlock;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class DumpOpcodes extends GhidraScript {
    @Override
    public void run() throws Exception {
        String outPath = System.getenv("OPCODE_OUT");
        if (outPath == null || outPath.trim().isEmpty()) {
            println("OPCODE_OUT not set.");
            return;
        }

        Listing listing = currentProgram.getListing();
        int count = 0;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outPath))) {
            for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
                if (!block.isExecute()) continue;

                InstructionIterator it =
                    listing.getInstructions(new AddressSet(block.getStart(), block.getEnd()), true);

                while (it.hasNext()) {
                    Instruction ins = it.next();
                    bw.write(ins.getAddress().toString());
                    bw.write("\t");
                    bw.write(ins.getMnemonicString()); // MOV, CALL, JMP, ...
                    bw.newLine();
                    count++;
                }
            }
        } catch (IOException e) {
            printerr("Error writing file: " + e.getMessage());
        }

        println("Dumped " + count + " instructions.");
    }
}
