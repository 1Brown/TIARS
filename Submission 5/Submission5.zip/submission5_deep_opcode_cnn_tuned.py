
from __future__ import annotations

import argparse
import copy
import json
import math
import random
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import StratifiedShuffleSplit
from torch import nn
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_PATH = SCRIPT_DIR / "preprocessed_opcodes" / "chunk_metadata.csv"
DEFAULT_OUTPUT_DIR = SCRIPT_DIR / "submission5_deep_results_tuned"

RANDOM_STATE = 42
DEFAULT_MIN_CHUNKS_PER_CLASS = 2
DEFAULT_MAX_CHUNKS_PER_CLASS = 300
DEFAULT_TEST_SIZE = 0.10
DEFAULT_VAL_SIZE_WITHIN_TRAIN = 0.10

DEFAULT_VOCAB_MIN_FREQ = 1
DEFAULT_SEQUENCE_LENGTH = 200

# Tuned but still faithful to the paper's single-conv CNN idea
DEFAULT_EMBED_DIM = 32
DEFAULT_NUM_FILTERS = 128
DEFAULT_KERNEL_SIZE = 8
DEFAULT_HIDDEN_DIM = 64
DEFAULT_DROPOUT = 0.30

DEFAULT_BATCH_SIZE = 32
DEFAULT_EPOCHS = 30
DEFAULT_LEARNING_RATE = 3e-3
DEFAULT_WEIGHT_DECAY = 1e-4
DEFAULT_LABEL_SMOOTHING = 0.05
DEFAULT_GRAD_CLIP_NORM = 5.0
DEFAULT_EARLY_STOPPING_PATIENCE = 8
DEFAULT_LR_SCHEDULER_PATIENCE = 3
DEFAULT_LR_SCHEDULER_FACTOR = 0.5
DEFAULT_USE_WEIGHTED_SAMPLER = True

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
RUN_LEARNING_CURVE_DEFAULT = True
LEARNING_CURVE_FRACTIONS = [0.10, 0.20, 0.40, 0.60, 0.80, 1.00]


@dataclass
class RunConfig:
    data_path: str
    output_dir: str
    random_state: int
    min_chunks_per_class: int
    max_chunks_per_class: int
    test_size: float
    val_size_within_train: float
    vocab_min_freq: int
    sequence_length: int
    embed_dim: int
    num_filters: int
    kernel_size: int
    hidden_dim: int
    dropout: float
    batch_size: int
    epochs: int
    learning_rate: float
    weight_decay: float
    label_smoothing: float
    grad_clip_norm: float
    early_stopping_patience: int
    lr_scheduler_patience: int
    lr_scheduler_factor: float
    use_weighted_sampler: bool
    device: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train a tuned single-convolution DeepOpcodeCNN for Submission 5."
    )
    parser.add_argument("--data-path", type=Path, default=DEFAULT_DATA_PATH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--min-chunks-per-class", type=int, default=DEFAULT_MIN_CHUNKS_PER_CLASS)
    parser.add_argument("--max-chunks-per-class", type=int, default=DEFAULT_MAX_CHUNKS_PER_CLASS)
    parser.add_argument("--test-size", type=float, default=DEFAULT_TEST_SIZE)
    parser.add_argument("--val-size-within-train", type=float, default=DEFAULT_VAL_SIZE_WITHIN_TRAIN)
    parser.add_argument("--vocab-min-freq", type=int, default=DEFAULT_VOCAB_MIN_FREQ)
    parser.add_argument("--sequence-length", type=int, default=DEFAULT_SEQUENCE_LENGTH)
    parser.add_argument("--embed-dim", type=int, default=DEFAULT_EMBED_DIM)
    parser.add_argument("--num-filters", type=int, default=DEFAULT_NUM_FILTERS)
    parser.add_argument("--kernel-size", type=int, default=DEFAULT_KERNEL_SIZE)
    parser.add_argument("--hidden-dim", type=int, default=DEFAULT_HIDDEN_DIM)
    parser.add_argument("--dropout", type=float, default=DEFAULT_DROPOUT)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--epochs", type=int, default=DEFAULT_EPOCHS)
    parser.add_argument("--learning-rate", type=float, default=DEFAULT_LEARNING_RATE)
    parser.add_argument("--weight-decay", type=float, default=DEFAULT_WEIGHT_DECAY)
    parser.add_argument("--label-smoothing", type=float, default=DEFAULT_LABEL_SMOOTHING)
    parser.add_argument("--grad-clip-norm", type=float, default=DEFAULT_GRAD_CLIP_NORM)
    parser.add_argument("--early-stopping-patience", type=int, default=DEFAULT_EARLY_STOPPING_PATIENCE)
    parser.add_argument("--lr-scheduler-patience", type=int, default=DEFAULT_LR_SCHEDULER_PATIENCE)
    parser.add_argument("--lr-scheduler-factor", type=float, default=DEFAULT_LR_SCHEDULER_FACTOR)
    parser.add_argument("--disable-weighted-sampler", action="store_true")
    parser.add_argument("--no-learning-curve", action="store_true")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


class OpcodeVocabulary:
    PAD = "<PAD>"
    UNK = "<UNK>"

    def __init__(self, min_freq: int = 1) -> None:
        self.min_freq = min_freq
        self.token_to_id: dict[str, int] = {self.PAD: 0, self.UNK: 1}
        self.id_to_token: list[str] = [self.PAD, self.UNK]

    def fit(self, texts: list[str]) -> None:
        counter: Counter[str] = Counter()
        for text in texts:
            counter.update(text.split())

        for token, freq in sorted(counter.items()):
            if freq >= self.min_freq and token not in self.token_to_id:
                self.token_to_id[token] = len(self.id_to_token)
                self.id_to_token.append(token)

    def encode(self, text: str, max_len: int) -> list[int]:
        ids = [self.token_to_id.get(tok, 1) for tok in text.split()]
        if len(ids) >= max_len:
            return ids[:max_len]
        return ids + [0] * (max_len - len(ids))

    @property
    def size(self) -> int:
        return len(self.id_to_token)


class OpcodeChunkDataset(Dataset):
    def __init__(self, texts: list[str], labels: list[int], vocab: OpcodeVocabulary, max_len: int) -> None:
        self.texts = texts
        self.labels = labels
        self.vocab = vocab
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        x = self.vocab.encode(self.texts[idx], self.max_len)
        y = self.labels[idx]
        return torch.tensor(x, dtype=torch.long), torch.tensor(y, dtype=torch.long)


class DeepOpcodeCNN(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        num_classes: int,
        embed_dim: int,
        num_filters: int,
        kernel_size: int,
        hidden_dim: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.conv = nn.Conv1d(
            in_channels=embed_dim,
            out_channels=num_filters,
            kernel_size=kernel_size,
            padding=kernel_size // 2,
        )
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.fc_hidden = nn.Linear(num_filters, hidden_dim)
        self.fc_out = nn.Linear(hidden_dim, num_classes)
        self._reset_parameters()

    def _reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.embedding.weight)
        if self.embedding.padding_idx is not None:
            with torch.no_grad():
                self.embedding.weight[self.embedding.padding_idx].fill_(0)
        nn.init.kaiming_uniform_(self.conv.weight, nonlinearity="relu")
        nn.init.zeros_(self.conv.bias)
        nn.init.kaiming_uniform_(self.fc_hidden.weight, nonlinearity="relu")
        nn.init.zeros_(self.fc_hidden.bias)
        nn.init.xavier_uniform_(self.fc_out.weight)
        nn.init.zeros_(self.fc_out.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        emb = self.embedding(x)              # [B, T, E]
        emb = emb.transpose(1, 2)            # [B, E, T]
        conv_out = self.relu(self.conv(emb)) # [B, F, T]
        pooled = torch.max(conv_out, dim=2).values
        hidden = self.relu(self.fc_hidden(self.dropout(pooled)))
        logits = self.fc_out(self.dropout(hidden))
        return logits


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Could not find dataset: {path}")

    df = pd.read_csv(path)
    required = {"label", "opcode_text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    df = df.dropna(subset=["label", "opcode_text"]).copy()
    df["label"] = df["label"].astype(str).str.strip()
    df["opcode_text"] = df["opcode_text"].astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
    df = df[(df["label"] != "") & (df["opcode_text"] != "")].reset_index(drop=True)
    return df


def filter_and_balance(
    df: pd.DataFrame,
    min_chunks_per_class: int,
    max_chunks_per_class: int,
    seed: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    counts = df["label"].value_counts().sort_index()
    keep_labels = counts[counts >= min_chunks_per_class].index.tolist()
    dropped_labels = counts[counts < min_chunks_per_class].to_dict()

    kept = df[df["label"].isin(keep_labels)].copy()
    sampled_parts: list[pd.DataFrame] = []
    for label, group in kept.groupby("label", sort=True):
        if len(group) > max_chunks_per_class:
            sampled_parts.append(group.sample(max_chunks_per_class, random_state=seed))
        else:
            sampled_parts.append(group)

    balanced = pd.concat(sampled_parts, ignore_index=True)
    balanced = balanced.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    summary = {
        "original_rows": int(len(df)),
        "filtered_rows": int(len(balanced)),
        "original_classes": int(df["label"].nunique()),
        "kept_classes": int(balanced["label"].nunique()),
        "dropped_classes_too_small": dropped_labels,
        "max_chunks_per_class": int(max_chunks_per_class),
        "min_chunks_per_class": int(min_chunks_per_class),
    }
    return balanced, summary


def make_splits(
    df: pd.DataFrame,
    test_size: float,
    val_size_within_train: float,
    seed: int,
) -> dict[str, pd.DataFrame]:
    X = df["opcode_text"].values
    y = df["label"].values

    outer = StratifiedShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
    train_val_idx, test_idx = next(outer.split(X, y))

    train_val_df = df.iloc[train_val_idx].reset_index(drop=True)
    test_df = df.iloc[test_idx].reset_index(drop=True)

    inner = StratifiedShuffleSplit(n_splits=1, test_size=val_size_within_train, random_state=seed)
    inner_train_idx, inner_val_idx = next(
        inner.split(train_val_df["opcode_text"].values, train_val_df["label"].values)
    )

    train_df = train_val_df.iloc[inner_train_idx].reset_index(drop=True)
    val_df = train_val_df.iloc[inner_val_idx].reset_index(drop=True)
    return {"train": train_df, "val": val_df, "test": test_df}


def build_label_maps(labels: list[str]) -> tuple[dict[str, int], dict[int, str]]:
    unique_labels = sorted(set(labels))
    label_to_id = {label: idx for idx, label in enumerate(unique_labels)}
    id_to_label = {idx: label for label, idx in label_to_id.items()}
    return label_to_id, id_to_label


def encode_labels(labels: list[str], label_to_id: dict[str, int]) -> list[int]:
    return [label_to_id[label] for label in labels]


def make_weighted_sampler(labels: list[int], seed: int) -> WeightedRandomSampler:
    label_counts = Counter(labels)
    sample_weights = [1.0 / label_counts[label] for label in labels]
    generator = torch.Generator()
    generator.manual_seed(seed)
    return WeightedRandomSampler(
        weights=torch.tensor(sample_weights, dtype=torch.double),
        num_samples=len(sample_weights),
        replacement=True,
        generator=generator,
    )


def make_loaders(
    splits: dict[str, pd.DataFrame],
    vocab_min_freq: int,
    sequence_length: int,
    batch_size: int,
    use_weighted_sampler: bool,
    seed: int,
) -> tuple[dict[str, DataLoader], OpcodeVocabulary, dict[str, int], dict[int, str]]:
    train_texts = splits["train"]["opcode_text"].tolist()
    all_labels_raw = (
        splits["train"]["label"].tolist()
        + splits["val"]["label"].tolist()
        + splits["test"]["label"].tolist()
    )
    label_to_id, id_to_label = build_label_maps(all_labels_raw)

    vocab = OpcodeVocabulary(min_freq=vocab_min_freq)
    vocab.fit(train_texts)

    pin_memory = DEVICE == "cuda"
    loaders: dict[str, DataLoader] = {}
    for split_name, split_df in splits.items():
        texts = split_df["opcode_text"].tolist()
        labels = encode_labels(split_df["label"].tolist(), label_to_id)
        dataset = OpcodeChunkDataset(texts, labels, vocab, sequence_length)

        sampler = None
        shuffle = False
        if split_name == "train":
            if use_weighted_sampler:
                sampler = make_weighted_sampler(labels, seed=seed)
            else:
                shuffle = True

        loaders[split_name] = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            sampler=sampler,
            num_workers=0,
            pin_memory=pin_memory,
        )

    return loaders, vocab, label_to_id, id_to_label


def compute_class_weights(train_labels: list[int], num_classes: int) -> torch.Tensor:
    counts = np.bincount(train_labels, minlength=num_classes).astype(np.float32)
    counts[counts == 0] = 1.0
    weights = counts.sum() / (len(counts) * counts)
    weights = weights / weights.mean()
    return torch.tensor(weights, dtype=torch.float32, device=DEVICE)


def build_loss_function(
    class_weights: torch.Tensor,
    label_smoothing: float,
) -> nn.Module:
    try:
        return nn.CrossEntropyLoss(weight=class_weights, label_smoothing=label_smoothing)
    except TypeError:
        return nn.CrossEntropyLoss(weight=class_weights)


def run_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer | None,
    grad_clip_norm: float,
) -> dict[str, float]:
    is_train = optimizer is not None
    model.train(is_train)

    total_loss = 0.0
    all_true: list[int] = []
    all_pred: list[int] = []

    for x_batch, y_batch in loader:
        x_batch = x_batch.to(DEVICE, non_blocking=True)
        y_batch = y_batch.to(DEVICE, non_blocking=True)

        if is_train:
            optimizer.zero_grad(set_to_none=True)

        logits = model(x_batch)
        loss = criterion(logits, y_batch)

        if is_train:
            loss.backward()
            if grad_clip_norm > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip_norm)
            optimizer.step()

        preds = torch.argmax(logits, dim=1)
        total_loss += float(loss.item()) * len(y_batch)
        all_true.extend(y_batch.detach().cpu().numpy().tolist())
        all_pred.extend(preds.detach().cpu().numpy().tolist())

    avg_loss = total_loss / max(1, len(loader.dataset))
    acc = accuracy_score(all_true, all_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(
        all_true,
        all_pred,
        average="macro",
        zero_division=0,
    )
    return {
        "loss": float(avg_loss),
        "accuracy": float(acc),
        "precision_macro": float(prec),
        "recall_macro": float(rec),
        "f1_macro": float(f1),
    }


@torch.no_grad()
def predict_all(model: nn.Module, loader: DataLoader) -> tuple[list[int], list[int]]:
    model.eval()
    y_true: list[int] = []
    y_pred: list[int] = []

    for x_batch, y_batch in loader:
        x_batch = x_batch.to(DEVICE, non_blocking=True)
        logits = model(x_batch)
        preds = torch.argmax(logits, dim=1).cpu().numpy().tolist()
        y_pred.extend(preds)
        y_true.extend(y_batch.numpy().tolist())

    return y_true, y_pred


def metrics_row(y_true: list[int], y_pred: list[int]) -> dict[str, float]:
    acc = accuracy_score(y_true, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="macro",
        zero_division=0,
    )
    return {
        "accuracy": float(acc),
        "precision_macro": float(prec),
        "recall_macro": float(rec),
        "f1_macro": float(f1),
    }


def split_distribution_df(splits: dict[str, pd.DataFrame]) -> pd.DataFrame:
    pieces: list[pd.DataFrame] = []
    for split_name, split_df in splits.items():
        counts = split_df["label"].value_counts().sort_index().rename("count").reset_index()
        counts.columns = ["label", "count"]
        counts.insert(0, "split", split_name)
        pieces.append(counts)
    return pd.concat(pieces, ignore_index=True)


def label_mapping_df(id_to_label: dict[int, str]) -> pd.DataFrame:
    return pd.DataFrame(
        [{"label_id": idx, "label_name": id_to_label[idx]} for idx in sorted(id_to_label.keys())]
    )


def test_predictions_df(
    test_df: pd.DataFrame,
    y_true: list[int],
    y_pred: list[int],
    id_to_label: dict[int, str],
) -> pd.DataFrame:
    out = test_df.copy().reset_index(drop=True)
    out["true_label_id"] = y_true
    out["pred_label_id"] = y_pred
    out["true_label_name"] = [id_to_label[idx] for idx in y_true]
    out["pred_label_name"] = [id_to_label[idx] for idx in y_pred]
    out["correct"] = out["true_label_id"] == out["pred_label_id"]
    return out


def classification_report_df(
    y_true: list[int],
    y_pred: list[int],
    id_to_label: dict[int, str],
) -> pd.DataFrame:
    labels = list(sorted(id_to_label.keys()))
    target_names = [id_to_label[i] for i in labels]
    report = classification_report(
        y_true,
        y_pred,
        labels=labels,
        target_names=target_names,
        output_dict=True,
        zero_division=0,
    )
    return pd.DataFrame(report).transpose().reset_index().rename(columns={"index": "label"})


def confusion_matrix_df(
    y_true: list[int],
    y_pred: list[int],
    id_to_label: dict[int, str],
) -> pd.DataFrame:
    labels = list(sorted(id_to_label.keys()))
    names = [id_to_label[i] for i in labels]
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    return pd.DataFrame(cm, index=names, columns=names)


def format_metric_block(summary: dict[str, Any]) -> str:
    df = pd.DataFrame(
        [
            {
                "classifier": "DeepOpcodeCNN_Tuned",
                "accuracy": round(summary["accuracy"], 4),
                "precision_macro": round(summary["precision_macro"], 4),
                "recall_macro": round(summary["recall_macro"], 4),
                "f1_macro": round(summary["f1_macro"], 4),
                "runtime_seconds": round(summary["runtime_seconds"], 2),
                "best_epoch": summary["best_epoch"],
            }
        ]
    )
    return df.to_string(index=False)


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def save_metrics(
    model: nn.Module,
    loaders: dict[str, DataLoader],
    splits: dict[str, pd.DataFrame],
    id_to_label: dict[int, str],
    train_history: list[dict[str, Any]],
    dataset_summary: dict[str, Any],
    split_summary: dict[str, int],
    runtime_seconds: float,
    output_dir: Path,
    config: RunConfig,
    best_epoch: int,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)

    y_true_test, y_pred_test = predict_all(model, loaders["test"])
    test_metrics = metrics_row(y_true_test, y_pred_test)
    report_df = classification_report_df(y_true_test, y_pred_test, id_to_label)
    cm_df = confusion_matrix_df(y_true_test, y_pred_test, id_to_label)

    summary = {
        "model": "DeepOpcodeCNN_Tuned",
        "accuracy": round(test_metrics["accuracy"], 4),
        "precision_macro": round(test_metrics["precision_macro"], 4),
        "recall_macro": round(test_metrics["recall_macro"], 4),
        "f1_macro": round(test_metrics["f1_macro"], 4),
        "device": DEVICE,
        "runtime_seconds": round(float(runtime_seconds), 2),
        "best_epoch": int(best_epoch),
        "dataset_summary": dataset_summary,
        "split_summary": split_summary,
        "config": asdict(config),
        "epochs": train_history,
    }

    deep_summary_df = pd.DataFrame(
        [
            {
                "classifier": "DeepOpcodeCNN_Tuned",
                "accuracy": summary["accuracy"],
                "precision_macro": summary["precision_macro"],
                "recall_macro": summary["recall_macro"],
                "f1_macro": summary["f1_macro"],
                "train_rows": split_summary["train_rows"],
                "val_rows": split_summary["val_rows"],
                "test_rows": split_summary["test_rows"],
                "num_classes": split_summary["num_classes"],
                "best_epoch": summary["best_epoch"],
                "elapsed_seconds": summary["runtime_seconds"],
            }
        ]
    )
    deep_summary_df.to_csv(output_dir / "deep_summary.csv", index=False)
    report_df.to_csv(output_dir / "DeepOpcodeCNN_classification_report.csv", index=False)
    cm_df.to_csv(output_dir / "DeepOpcodeCNN_confusion_matrix.csv")
    test_predictions_df(splits["test"], y_true_test, y_pred_test, id_to_label).to_csv(
        output_dir / "DeepOpcodeCNN_test_predictions.csv",
        index=False,
    )
    label_mapping_df(id_to_label).to_csv(output_dir / "label_mapping.csv", index=False)
    split_distribution_df(splits).to_csv(output_dir / "split_label_distribution.csv", index=False)
    pd.DataFrame(train_history).to_csv(output_dir / "epoch_history.csv", index=False)

    with (output_dir / "run_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    torch.save(model.state_dict(), output_dir / "deep_opcode_cnn_tuned.pt")

    console_lines = [
        "================ FINAL TEST RESULTS ================",
        format_metric_block(summary),
        "",
        "================ TEST CLASSIFICATION REPORT ================",
        report_df.round(4).to_string(index=False),
        "",
        "================ TEST CONFUSION MATRIX ================",
        cm_df.to_string(),
        "",
        "================ OUTPUT FILES ================",
        "deep_summary.csv",
        "run_summary.json",
        "epoch_history.csv",
        "DeepOpcodeCNN_classification_report.csv",
        "DeepOpcodeCNN_confusion_matrix.csv",
        "DeepOpcodeCNN_test_predictions.csv",
        "label_mapping.csv",
        "split_label_distribution.csv",
        "deep_opcode_cnn_tuned.pt",
    ]
    write_text(output_dir / "final_console_summary.txt", "\n".join(console_lines) + "\n")

    return {
        "summary": summary,
        "report_df": report_df,
        "cm_df": cm_df,
    }


def train_main_model(
    loaders: dict[str, DataLoader],
    num_classes: int,
    config: RunConfig,
) -> tuple[nn.Module, list[dict[str, Any]], float, int]:
    model = DeepOpcodeCNN(
        vocab_size=loaders["train"].dataset.vocab.size,
        num_classes=num_classes,
        embed_dim=config.embed_dim,
        num_filters=config.num_filters,
        kernel_size=config.kernel_size,
        hidden_dim=config.hidden_dim,
        dropout=config.dropout,
    ).to(DEVICE)

    train_labels = loaders["train"].dataset.labels
    class_weights = compute_class_weights(train_labels, num_classes)
    criterion = build_loss_function(class_weights, config.label_smoothing)
    optimizer = torch.optim.RMSprop(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
        alpha=0.99,
        momentum=0.0,
    )
    scheduler = ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=config.lr_scheduler_factor,
        patience=config.lr_scheduler_patience,
    )

    history: list[dict[str, Any]] = []
    best_val_f1 = -1.0
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improvement = 0

    start = time.time()
    for epoch in range(1, config.epochs + 1):
        train_metrics = run_epoch(model, loaders["train"], criterion, optimizer, config.grad_clip_norm)
        val_metrics = run_epoch(model, loaders["val"], criterion, None, config.grad_clip_norm)
        scheduler.step(val_metrics["f1_macro"])

        current_lr = float(optimizer.param_groups[0]["lr"])
        row = {
            "epoch": epoch,
            "lr": round(current_lr, 8),
            **{f"train_{k}": round(v, 4) for k, v in train_metrics.items()},
            **{f"val_{k}": round(v, 4) for k, v in val_metrics.items()},
        }
        history.append(row)

        print(
            f"[EPOCH {epoch:02d}] "
            f"lr={current_lr:.6f} "
            f"train_loss={train_metrics['loss']:.4f} "
            f"train_acc={train_metrics['accuracy']:.4f} "
            f"train_f1={train_metrics['f1_macro']:.4f} "
            f"val_loss={val_metrics['loss']:.4f} "
            f"val_acc={val_metrics['accuracy']:.4f} "
            f"val_f1={val_metrics['f1_macro']:.4f}"
        )

        if val_metrics["f1_macro"] > best_val_f1:
            best_val_f1 = val_metrics["f1_macro"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1

        if epochs_without_improvement >= config.early_stopping_patience:
            print(f"[INFO] Early stopping at epoch {epoch}. Best epoch was {best_epoch}.")
            break

    runtime = time.time() - start

    if best_state is not None:
        model.load_state_dict(best_state)

    return model, history, runtime, best_epoch


def build_stratified_subset_loader(
    loader: DataLoader,
    fraction: float,
    batch_size: int,
    use_weighted_sampler: bool,
    seed: int,
) -> DataLoader:
    dataset: OpcodeChunkDataset = loader.dataset
    texts = dataset.texts
    labels = np.array(dataset.labels)

    if fraction >= 1.0:
        idx = np.arange(len(labels))
    else:
        splitter = StratifiedShuffleSplit(
            n_splits=1,
            train_size=fraction,
            random_state=seed,
        )
        idx, _ = next(splitter.split(np.zeros(len(labels)), labels))

    idx = sorted(idx.tolist())
    subset_texts = [texts[i] for i in idx]
    subset_labels = labels[idx].tolist()
    subset_dataset = OpcodeChunkDataset(subset_texts, subset_labels, dataset.vocab, dataset.max_len)

    sampler = None
    shuffle = False
    if use_weighted_sampler:
        sampler = make_weighted_sampler(subset_labels, seed=seed)
    else:
        shuffle = True

    return DataLoader(
        subset_dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        sampler=sampler,
        num_workers=0,
        pin_memory=(DEVICE == "cuda"),
    )


def run_learning_curve(
    loaders: dict[str, DataLoader],
    num_classes: int,
    output_dir: Path,
    config: RunConfig,
) -> None:
    rows: list[dict[str, Any]] = []
    full_val_loader = loaders["val"]

    for frac in LEARNING_CURVE_FRACTIONS:
        set_seed(config.random_state)

        subset_train_loader = build_stratified_subset_loader(
            loaders["train"],
            frac,
            batch_size=config.batch_size,
            use_weighted_sampler=config.use_weighted_sampler,
            seed=config.random_state,
        )
        model = DeepOpcodeCNN(
            vocab_size=loaders["train"].dataset.vocab.size,
            num_classes=num_classes,
            embed_dim=config.embed_dim,
            num_filters=config.num_filters,
            kernel_size=config.kernel_size,
            hidden_dim=config.hidden_dim,
            dropout=config.dropout,
        ).to(DEVICE)

        train_labels = subset_train_loader.dataset.labels
        class_weights = compute_class_weights(train_labels, num_classes)
        criterion = build_loss_function(class_weights, config.label_smoothing)
        optimizer = torch.optim.RMSprop(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
            alpha=0.99,
            momentum=0.0,
        )
        scheduler = ReduceLROnPlateau(
            optimizer,
            mode="max",
            factor=config.lr_scheduler_factor,
            patience=max(1, config.lr_scheduler_patience // 2),
        )

        best_val_f1 = -1.0
        best_state = None

        for _ in range(config.epochs):
            run_epoch(model, subset_train_loader, criterion, optimizer, config.grad_clip_norm)
            val_metrics = run_epoch(model, full_val_loader, criterion, None, config.grad_clip_norm)
            scheduler.step(val_metrics["f1_macro"])

            if val_metrics["f1_macro"] > best_val_f1:
                best_val_f1 = val_metrics["f1_macro"]
                best_state = copy.deepcopy(model.state_dict())

        if best_state is not None:
            model.load_state_dict(best_state)

        train_metrics = run_epoch(model, subset_train_loader, criterion, None, config.grad_clip_norm)
        val_metrics = run_epoch(model, full_val_loader, criterion, None, config.grad_clip_norm)

        rows.append(
            {
                "train_fraction": frac,
                "train_rows": len(subset_train_loader.dataset),
                "train_f1_macro": round(train_metrics["f1_macro"], 4),
                "val_f1_macro": round(val_metrics["f1_macro"], 4),
                "train_error_1_minus_f1": round(1.0 - train_metrics["f1_macro"], 4),
                "val_error_1_minus_f1": round(1.0 - val_metrics["f1_macro"], 4),
            }
        )
        print(
            f"[LC] frac={frac:.2f} rows={len(subset_train_loader.dataset)} "
            f"train_f1={train_metrics['f1_macro']:.4f} "
            f"val_f1={val_metrics['f1_macro']:.4f} "
            f"train_err={1.0 - train_metrics['f1_macro']:.4f} "
            f"val_err={1.0 - val_metrics['f1_macro']:.4f}"
        )

    pd.DataFrame(rows).to_csv(output_dir / "learning_curve.csv", index=False)


def print_final_results(saved: dict[str, Any], output_dir: Path, learning_curve_enabled: bool) -> None:
    summary = saved["summary"]
    report_df: pd.DataFrame = saved["report_df"]
    cm_df: pd.DataFrame = saved["cm_df"]

    print("\n================ FINAL TEST RESULTS ================")
    print(format_metric_block(summary))

    print("\n================ TEST CLASSIFICATION REPORT ================")
    print(report_df.round(4).to_string(index=False))

    print("\n================ TEST CONFUSION MATRIX ================")
    print(cm_df.to_string())

    print("\n================ OUTPUT FILES ================")
    files_written = [
        "deep_summary.csv",
        "run_summary.json",
        "epoch_history.csv",
        "DeepOpcodeCNN_classification_report.csv",
        "DeepOpcodeCNN_confusion_matrix.csv",
        "DeepOpcodeCNN_test_predictions.csv",
        "label_mapping.csv",
        "split_label_distribution.csv",
        "final_console_summary.txt",
        "deep_opcode_cnn_tuned.pt",
    ]
    if learning_curve_enabled:
        files_written.append("learning_curve.csv")

    for name in files_written:
        print(f"- {output_dir / name}")


def main() -> None:
    args = parse_args()
    set_seed(RANDOM_STATE)
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    config = RunConfig(
        data_path=str(args.data_path),
        output_dir=str(output_dir),
        random_state=RANDOM_STATE,
        min_chunks_per_class=args.min_chunks_per_class,
        max_chunks_per_class=args.max_chunks_per_class,
        test_size=args.test_size,
        val_size_within_train=args.val_size_within_train,
        vocab_min_freq=args.vocab_min_freq,
        sequence_length=args.sequence_length,
        embed_dim=args.embed_dim,
        num_filters=args.num_filters,
        kernel_size=args.kernel_size,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
        batch_size=args.batch_size,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        label_smoothing=args.label_smoothing,
        grad_clip_norm=args.grad_clip_norm,
        early_stopping_patience=args.early_stopping_patience,
        lr_scheduler_patience=args.lr_scheduler_patience,
        lr_scheduler_factor=args.lr_scheduler_factor,
        use_weighted_sampler=(not args.disable_weighted_sampler),
        device=DEVICE,
    )

    print(f"[INFO] Device: {DEVICE}")
    print(f"[INFO] Loading data from: {args.data_path}")

    df = load_data(args.data_path)
    df_balanced, dataset_summary = filter_and_balance(
        df,
        min_chunks_per_class=config.min_chunks_per_class,
        max_chunks_per_class=config.max_chunks_per_class,
        seed=config.random_state,
    )
    splits = make_splits(
        df_balanced,
        test_size=config.test_size,
        val_size_within_train=config.val_size_within_train,
        seed=config.random_state,
    )

    split_summary = {
        "train_rows": int(len(splits["train"])),
        "val_rows": int(len(splits["val"])),
        "test_rows": int(len(splits["test"])),
        "num_classes": int(df_balanced["label"].nunique()),
    }

    print(f"[INFO] Original rows: {dataset_summary['original_rows']}")
    print(f"[INFO] Filtered rows: {dataset_summary['filtered_rows']}")
    print(f"[INFO] Kept classes: {dataset_summary['kept_classes']}")
    print(f"[INFO] Split sizes: {split_summary}")
    if dataset_summary["dropped_classes_too_small"]:
        print(f"[INFO] Dropped tiny classes: {dataset_summary['dropped_classes_too_small']}")

    loaders, vocab, label_to_id, id_to_label = make_loaders(
        splits=splits,
        vocab_min_freq=config.vocab_min_freq,
        sequence_length=config.sequence_length,
        batch_size=config.batch_size,
        use_weighted_sampler=config.use_weighted_sampler,
        seed=config.random_state,
    )
    num_classes = len(label_to_id)

    print(f"[INFO] Vocabulary size: {vocab.size}")
    print("[INFO] Training DeepOpcodeCNN_Tuned...")
    model, history, runtime, best_epoch = train_main_model(loaders, num_classes, config)

    saved = save_metrics(
        model=model,
        loaders=loaders,
        splits=splits,
        id_to_label=id_to_label,
        train_history=history,
        dataset_summary=dataset_summary,
        split_summary=split_summary,
        runtime_seconds=runtime,
        output_dir=output_dir,
        config=config,
        best_epoch=best_epoch,
    )

    learning_curve_enabled = not args.no_learning_curve
    if learning_curve_enabled:
        print("[INFO] Running learning-curve experiment...")
        run_learning_curve(loaders, num_classes, output_dir, config)

    print_final_results(saved, output_dir, learning_curve_enabled)


if __name__ == "__main__":
    main()
