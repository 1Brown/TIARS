# Submission 5 — Deep Android Malware Detection on Collected Opcode Sequences

## Overview
This folder contains the code and outputs for **Submission 5**, which implements a deep learning approach inspired by **Deep Android Malware Detection** on the collected opcode dataset from Submission 4.

The goal of this submission is to:
- train a CNN directly on opcode-token sequences,
- evaluate the model on a held-out test split,
- compare it against the Submission 4 classical baselines,
- provide reproducible scripts and output files for grading.

This project uses the **already prepared opcode chunk dataset** from Submission 4, so no APK disassembly step is required for the main experiment.

---

## Main Files

### Required script
- `submission5_deep_opcode_cnn_tuned.py`  
  Final tuned deep CNN training/evaluation script.

### Input data
- `preprocessed_opcodes/chunk_metadata.csv`  
  Input dataset used by the deep model.

### Main output folder
- `submission5_deep_results_tuned/`

---

## Expected Input Format
The script expects a CSV file named `chunk_metadata.csv` with at least these columns:

- `label` — malware family label
- `opcode_text` — whitespace-separated opcode sequence

Other columns such as `source_file`, `chunk_id`, and `chunk_length` may be present, but they are not required by the model.

Example columns:
- `source_file`
- `label`
- `chunk_id`
- `chunk_length`
- `opcode_text`

---

## Environment
This project was run in **Python 3.13** on Windows using CPU-based PyTorch.

Install dependencies with:

```bash
py -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
py -m pip install pandas numpy scikit-learn matplotlib
```

---

## How to Run

### 1. Place the dataset in the expected location
Default expected path:

```text
preprocessed_opcodes/chunk_metadata.csv
```

If your file is already there, no extra step is needed.

### 2. Run the tuned deep model
```bash
py submission5_deep_opcode_cnn_tuned.py
```

### 3. Optional: skip the learning curve for a faster run
```bash
py submission5_deep_opcode_cnn_tuned.py --no-learning-curve
```

### 4. Optional: specify a custom dataset path
```bash
py submission5_deep_opcode_cnn_tuned.py --data-path "C:\path\to\chunk_metadata.csv"
```

---

## What the Script Does

1. Loads `chunk_metadata.csv`
2. Drops classes with too few samples
3. Caps classes at a maximum chunk count for balance/runtime control
4. Splits the data into train/validation/test sets
5. Builds an opcode vocabulary from training data only
6. Trains a paper-inspired CNN on opcode sequences
7. Selects the best checkpoint using validation performance
8. Evaluates the final model on the held-out test set
9. Saves metrics, reports, predictions, and training history

---

## Model Summary
The final tuned model keeps the same core paper-inspired structure:

- opcode embedding layer
- 1D convolution over opcode tokens
- global max pooling
- fully connected hidden layer
- final classifier layer

Key settings used in the tuned run:
- embedding dimension: 32
- convolution filters: 128
- kernel size: 8
- hidden dimension: 64
- dropout: 0.3
- batch size: 32
- epochs: 30
- optimizer: RMSProp
- learning rate: 0.003
- weight decay: 0.0001
- label smoothing: 0.05
- weighted sampling enabled
- learning-rate scheduler enabled

---

## Output Files
After a successful run, the script writes outputs to:

```text
submission5_deep_results_tuned/
```

Main files include:

- `deep_summary.csv`  
  Final summary metrics for the tuned deep model

- `run_summary.json`  
  Full run configuration and recorded results

- `epoch_history.csv`  
  Training/validation history by epoch

- `learning_curve.csv`  
  Learning-curve results showing performance vs training-set size

- `DeepOpcodeCNN_classification_report.csv`  
  Per-class precision, recall, F1, and support

- `DeepOpcodeCNN_confusion_matrix.csv`  
  Confusion matrix for the final test set

- `DeepOpcodeCNN_test_predictions.csv`  
  Final test predictions

- `split_label_distribution.csv`  
  Train/validation/test label counts

- `label_mapping.csv`  
  Class-to-index mapping used by the model

- `deep_opcode_cnn.pt`  
  Saved best model weights

- `final_console_summary.txt`  
  Final console-style summary of the run

---

## Interpreting the Results
Important metrics to focus on:

- **Accuracy** — overall percentage correct
- **Macro Precision** — average precision across classes
- **Macro Recall** — average recall across classes
- **Macro F1** — primary balanced performance metric for multi-class evaluation

Macro F1 is especially important here because the malware-family classes are not perfectly balanced.

---

## Submission 4 Baselines Used for Comparison
The deep model was compared against the classical baselines from Submission 4:

- **LinearSVM**
- **KNN (k=3)**
- **DecisionTree**

Baseline summary:

| Classifier | Accuracy | Macro Precision | Macro Recall | Macro F1 |
|---|---:|---:|---:|---:|
| LinearSVM | 60.24% | 56.36% | 52.55% | 52.45% |
| KNN_k3 | 55.32% | 49.00% | 47.11% | 46.95% |
| DecisionTree | 44.77% | 35.36% | 32.79% | 33.30% |

Final tuned Submission 5 deep model:

| Classifier | Accuracy | Macro Precision | Macro Recall | Macro F1 |
|---|---:|---:|---:|---:|
| DeepOpcodeCNN_Tuned | 68.73% | 62.55% | 64.74% | 61.36% |

---

## Reproducibility Notes
To reproduce the graded run as closely as possible:

1. Use the provided `chunk_metadata.csv`
2. Run the tuned script with default settings
3. Do not change the random seed
4. Keep the default class filtering and class cap settings
5. Use the generated output files for evaluation and report figures

This project uses:
- fixed random seed
- stratified splitting
- a separate validation set
- a held-out test set
- best-checkpoint selection based on validation performance

---

## Important Adaptation Note
The original paper begins from APK disassembly and opcode extraction.  
This course project begins from **already collected opcode sequences**, so the implementation starts at the opcode-sequence stage rather than the APK stage.

This is an intentional adaptation for the available dataset and still preserves the paper’s main learning idea: applying a CNN directly to opcode-token sequences instead of relying only on manually engineered features.

---

## Optional Figure Generation
If the output CSV files have already been created, report figures can be generated separately from those outputs.  
This includes:
- accuracy comparison charts,
- macro F1 comparison charts,
- training curves,
- learning curves,
- confusion matrix,
- per-class F1 charts.

---

## Reference
Primary paper used for this submission:

McLaughlin, N., Martinez del Rincon, J., Kang, B., Yerima, S., Miller, P., and Sezer, S.,  
**“Deep Android Malware Detection,”**  
*Proceedings of the Seventh ACM on Conference on Data and Application Security and Privacy (CODASPY '17)*, 2017.

---

## TA Quick Start
If you only want the minimum steps needed to run the project:

```bash
py -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
py -m pip install pandas numpy scikit-learn matplotlib
py submission5_deep_opcode_cnn_tuned.py
```

Then review the files in:

```text
submission5_deep_results_tuned/
```
